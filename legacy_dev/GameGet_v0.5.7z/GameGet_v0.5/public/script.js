      
document.addEventListener('DOMContentLoaded', () => { // Ensure DOM is loaded before running script

    // --- DOM Element References ---
    const gameInput = document.getElementById('gameInput');
    const searchButton = document.getElementById('searchButton');
    const resultsDiv = document.getElementById('results');

    // Settings Panel Elements
    const settingsCog = document.getElementById('settings-cog');
    const settingsPanel = document.getElementById('settings-panel');
    const settingsClose = document.getElementById('settings-close');
    const themeRadios = document.querySelectorAll('input[name="theme"]');
    const fontSelector = document.getElementById('font-selector');

    const API_BASE_URL = 'http://localhost:3000'; // Backend API URL

    // --- Global Event Listeners ---
    searchButton.addEventListener('click', searchGamesList);
    gameInput.addEventListener('keypress', (event) => {
        // Allow searching by pressing Enter in the input field
        if (event.key === 'Enter') {
            searchGamesList();
        }
    });

    // Settings Panel Listeners
    settingsCog.addEventListener('click', () => {
        settingsPanel.classList.add('visible'); // Show panel
    });

    settingsClose.addEventListener('click', () => {
        settingsPanel.classList.remove('visible'); // Hide panel
    });

    // Close settings panel if user clicks outside of it
    document.addEventListener('click', (event) => {
        // Check if the click is outside the panel and not on the cog button
        if (!settingsPanel.contains(event.target) && !settingsCog.contains(event.target) && settingsPanel.classList.contains('visible')) {
           settingsPanel.classList.remove('visible');
        }
    });

    // Theme Change Listener
    themeRadios.forEach(radio => {
        radio.addEventListener('change', (event) => {
            // Apply theme when a radio button is selected
            applyTheme(event.target.value);
        });
    });

    // Font Change Listener
    fontSelector.addEventListener('change', (event) => {
        // Apply font when selection changes
        applyFont(event.target.value);
    });

    // --- Settings Management Functions ---
    function applyTheme(themeName) {
        console.log("Applying theme:", themeName);
        // Set the data-theme attribute on the body
        document.body.dataset.theme = themeName;
        // Save the selected theme to localStorage for persistence
        localStorage.setItem('selectedTheme', themeName);
    }

    function applyFont(fontName) {
        console.log("Applying font:", fontName);
        // Set the --body-font CSS variable on the body
        document.body.style.setProperty('--body-font', fontName);
        // Save the selected font to localStorage
        localStorage.setItem('selectedFont', fontName);
    }

    function loadSettings() {
        // Retrieve saved settings from localStorage
        const savedTheme = localStorage.getItem('selectedTheme');
        const savedFont = localStorage.getItem('selectedFont');

        // Apply saved theme or use a default theme ('light')
        const defaultTheme = 'light';
        const themeToApply = savedTheme || defaultTheme;
        applyTheme(themeToApply);

        // Update the checked state of the corresponding radio button
        const currentThemeRadio = document.querySelector(`input[name="theme"][value="${themeToApply}"]`);
        if (currentThemeRadio) {
            currentThemeRadio.checked = true;
        }

         // Apply saved font if it exists
        if (savedFont) {
            applyFont(savedFont);
             // Update the selected option in the dropdown
             fontSelector.value = savedFont;
        }
        // If no font is saved, the default font from CSS (:root) will be used.
        console.log(`Loaded settings: Theme='${themeToApply}', Font='${savedFont || 'Default'}'`);
    }

    // --- Platform Logo Mapping Helper Function ---
    function getLogoPathForPlatform(platformName) {
        // Normalize the platform name to lowercase for easier matching
        const nameLower = platformName.toLowerCase();
        // Base path for platform logo images (relative to the public folder)
        const basePath = 'images/platforms/';

        // --- Mapping Logic: Match substrings in platform names ---
        // Add more specific cases before general ones (e.g., ps5 before playstation)
        if (nameLower.includes('windows') || nameLower.includes('mswin')) {
            return basePath + 'windows.png';
		} else if (nameLower.includes('ms-dos') || nameLower.includes('dos')) {
            return basePath + 'dos.png';
		} else if (nameLower.includes('pc-98') || nameLower.includes('NEC PC-9800')) {
            return basePath + 'pc98.png';
		} else if (nameLower.includes('pc')) { // General fallback for generic pc
            return basePath + 'pc.gif';
        } else if (nameLower.includes('playstation 5') || nameLower.includes('ps5')) {
            return basePath + 'ps5.png';
        } else if (nameLower.includes('playstation 4') || nameLower.includes('ps4')) {
            return basePath + 'ps4.png';
        } else if (nameLower.includes('playstation 3') || nameLower.includes('ps3')) {
            return basePath + 'ps3.png'; 
        } else if (nameLower.includes('playstation 2') || nameLower.includes('ps2')) {
            return basePath + 'ps2.png'; 
        } else if (nameLower.includes('playstation vita')) {
            return basePath + 'psvita.png';
        } else if (nameLower.includes('psp') || nameLower.includes('playstation portable')) {
            return basePath + 'psp.png';
        } else if (nameLower.includes('playstation') || nameLower.includes('psx') || nameLower.includes('ps1')) {
            return basePath + 'playstation.png';
        } else if (nameLower.includes('xbox series')) { // Catches X and S
            return basePath + 'xboxseriesx.png';
        } else if (nameLower.includes('xbox one')) {
            return basePath + 'xboxone.png';
        } else if (nameLower.includes('xbox 360')) {
            return basePath + 'xbox360.png'; 
        } else if (nameLower.includes('xbox')) { // General fallback for Xbox
            return basePath + 'xbox.png';
        } else if (nameLower.includes('switch')) {
            return basePath + 'switch.png';
        } else if (nameLower.includes('wii u')) {
            return basePath + 'wiiu.png';
        } else if (nameLower.includes('wii')) {
            return basePath + 'wii.png'; 
        } else if (nameLower.includes('nintendo 3ds')) {
            return basePath + '3ds.png'; 
        } else if (nameLower.includes('nintendo ds')) {
            return basePath + 'nds.png'; 
        } else if (nameLower.includes('gamecube') || nameLower.includes('ngc')) {
            return basePath + 'gamecube.png'; 
        } else if (nameLower.includes('nintendo 64') || nameLower.includes('n64')) {
            return basePath + 'n64.png'; 
		} else if (nameLower.includes('64DD') || nameLower.includes('Nintendo 64DD')) {
            return basePath + '64dd.png'; 
        } else if (nameLower.includes('snes') || nameLower.includes('super nintendo')) {
            return basePath + 'snes.png';
		} else if (nameLower.includes('super famicom') || nameLower.includes('SFC')) {
            return basePath + 'snes.png';
		} else if (nameLower.includes('sega mega drive') || nameLower.includes('sega genesis')) { 
            return basePath + 'md.png';			
        } else if (nameLower.includes('nintendo entertainment system') || nameLower.includes('nes')) {
            return basePath + 'nintendo.png'; 
        } else if (nameLower.includes('linux')) {
            return basePath + 'linux.png';
        } else if (nameLower.includes('mac') || nameLower.includes('macos')) {
            return basePath + 'mac.png';
        } else if (nameLower.includes('android')) {
            return basePath + 'android.png';
        } else if (nameLower.includes('ios')) {
            return basePath + 'ios.png';
        } else if (nameLower.includes('stadia')) {
            return basePath + 'stadia.png';
		} else if (nameLower.includes('tapwave') || nameLower.includes('tapwave zodiac')) {
            return basePath + 'tapwave.png';
		} else if (nameLower.includes('atari 2600') || nameLower.includes('Atari VCS')) {
            return basePath + 'atari2600.png';
		} else if (nameLower.includes('atari 5200') || nameLower.includes('Atari 5200 SuperSystem')) {
            return basePath + 'atari5200.png';
		} else if (nameLower.includes('atari')) { // General fallback for atari
            return basePath + 'atari.png';
		} else if (nameLower.includes('amiga') || nameLower.includes('Commodore Amiga')) { // General fallback for amiga
            return basePath + 'amiga.png';
		} else if (nameLower.includes('amiga cd32')) { 
            return basePath + 'cd32.png';
		} else if (nameLower.includes('sega dreamcast') || nameLower.includes('dreamcast')) { 
            return basePath + 'dreamcast.png';
		} else if (nameLower.includes('master system') || nameLower.includes('sega master system')) { 
            return basePath + 'mastersystem.png';
		} else if (nameLower.includes('saturn') || nameLower.includes('sega saturn')) { 
            return basePath + 'saturn.png';
        }
        // Add more mappings here for other consoles/platforms as needed...

        // Default fallback icon if no specific match is found
        console.warn(`No specific logo found for platform: "${platformName}", using default.`);
        return basePath + 'default.png'; // Ensure you have default.png
    }

    // --- Core Search and Display Functions ---

    /**
     * Initiates the search process by calling the backend /search endpoint.
     */
    async function searchGamesList() {
        const gameName = gameInput.value.trim();
        if (!gameName) {
            resultsDiv.innerHTML = '<p class="error-message">Please enter a game name.</p>';
            return;
        }
        resultsDiv.innerHTML = '<p class="info-message loading">Searching IGDB...</p>';
        searchButton.disabled = true;
        try {
            const response = await fetch(`${API_BASE_URL}/search?gameName=${encodeURIComponent(gameName)}`);
            if (!response.ok) {
                const errorData = await response.json().catch(() => ({ error: 'Unknown server error or non-JSON response' }));
                throw new Error(`Server error: ${response.status} - ${errorData.error || response.statusText}`);
            }
            const searchResults = await response.json();
            if (searchResults && searchResults.length > 0) {
                displaySearchResultsList(searchResults);
            } else {
                 resultsDiv.innerHTML = `<p class="info-message">No games found matching "${gameName}".</p>`;
            }
        } catch (error) {
            console.error('Search List Fetch Error:', error);
            resultsDiv.innerHTML = `<p class="error-message">Error: ${error.message}. Could not fetch game list.</p>`;
        } finally {
             searchButton.disabled = false;
        }
    }

    /**
     * Displays the list of search results.
     * @param {Array<object>} results - Array of game objects ({id, name, year}).
     */
    function displaySearchResultsList(results) {
        resultsDiv.innerHTML = '';
        const instruction = document.createElement('p');
        instruction.classList.add('info-message');
        instruction.textContent = 'Select a game to view details:';
        resultsDiv.appendChild(instruction);
        const list = document.createElement('ul');
        list.classList.add('search-results-list');
        results.forEach(game => {
            const item = document.createElement('li');
            item.classList.add('search-result-item');
            item.dataset.gameId = game.id;
            const nameSpan = document.createElement('span');
            nameSpan.textContent = game.name;
            nameSpan.classList.add('game-title');
            const dateSpan = document.createElement('span');
            dateSpan.textContent = `(${game.year || 'N/A'})`;
            dateSpan.classList.add('game-shortdate');
            item.appendChild(nameSpan);
            item.appendChild(dateSpan);
            item.addEventListener('click', () => {
                fetchGameDetails(game.id);
            });
            list.appendChild(item);
        });
        resultsDiv.appendChild(list);
    }

    /**
     * Fetches full details for a specific game ID from the backend.
     * @param {number} gameId - The IGDB ID of the game to fetch.
     */
    async function fetchGameDetails(gameId) {
        resultsDiv.innerHTML = '<p class="info-message loading">Loading details...</p>';
        searchButton.disabled = true;
        try {
            const response = await fetch(`${API_BASE_URL}/details/${gameId}`);
            if (!response.ok) {
                 const errorData = await response.json().catch(() => ({ error: 'Unknown server error or non-JSON response' }));
                 throw new Error(`Server error: ${response.status} - ${errorData.error || response.statusText}`);
            }
            const gameDetails = await response.json();
            displayGameDetails(gameDetails);
        } catch (error) {
            console.error('Fetch Details Error:', error);
            resultsDiv.innerHTML = `<p class="error-message">Error loading details: ${error.message}.</p>`;
        } finally {
            searchButton.disabled = false;
        }
    }


    /**
     * Displays the full details of a selected game. Uses local logos.
     * @param {object} data - The game data object from the backend {name, thumbnailUrl, releaseDate, platforms: [name1, name2, ...]}.
     */
    function displayGameDetails(data) {
        if (!data || !data.name) {
             resultsDiv.innerHTML = '<p class="info-message">Could not extract valid game details.</p>';
             return;
        }
        resultsDiv.innerHTML = ''; // Clear previous results

        const gameInfoDiv = document.createElement('div');
        gameInfoDiv.classList.add('game-info');

        // --- Thumbnail ---
        const imgElement = document.createElement('img');
        imgElement.src = data.thumbnailUrl || 'https://via.placeholder.com/120x160?text=No+Art';
        imgElement.alt = `${data.name} Box Art`;
        imgElement.onerror = () => { // Handle broken image links
            imgElement.src = 'https://via.placeholder.com/120x160?text=Art+Error';
            imgElement.alt = 'Image failed to load';
        };

        // --- Text Details Container ---
        const detailsDiv = document.createElement('div');
        detailsDiv.classList.add('game-details');

        // Game Name
        const nameElement = document.createElement('h2');
        nameElement.textContent = data.name;
        detailsDiv.appendChild(nameElement);

        // Release Date
        const releaseElement = document.createElement('p');
        releaseElement.innerHTML = `<strong>Release Date:</strong> ${data.releaseDate || 'N/A'}`;
        detailsDiv.appendChild(releaseElement);

        // Platforms Header
        const platformsElement = document.createElement('p');
        platformsElement.innerHTML = '<strong>Platforms:</strong>';
        detailsDiv.appendChild(platformsElement);

        // --- Platform List Creation (Using Local Logos) ---
        if (data.platforms && data.platforms.length > 0) {
            const platformList = document.createElement('ul');
            // data.platforms is now an array of names ["PC (Microsoft Windows)", "PlayStation 5", ...]
            // Inside displayGameDetails, within the platform loop:
    data.platforms.forEach(platformName => { // platformName SHOULD be a string here
        console.log("Processing platform:", platformName, typeof platformName); // <<< ADD THIS LOG

        const li = document.createElement('li');
        li.classList.add('platform-item');

        // Get the path to the local logo using the helper function
        // Ensure platformName is actually a string before calling toLowerCase
        let logoPath = 'images/platforms/default.png'; // Default path
        if (typeof platformName === 'string') {
             logoPath = getLogoPathForPlatform(platformName); // <<< ERROR occurs inside here
        } else {
             console.error("Invalid platform data type found:", platformName);
        }


        // Create and add the logo image
        const logoImg = document.createElement('img');
        logoImg.src = logoPath; // Use the local path (or default)
        // ... rest of image creation ...
        li.appendChild(logoImg);


        // Create and add the platform name text
        const platformNameSpan = document.createElement('span');
         // Display the name if it's a string, otherwise show 'Invalid Data'
         platformNameSpan.textContent = (typeof platformName === 'string') ? platformName : '[Invalid Data]';
        li.appendChild(platformNameSpan);

        platformList.appendChild(li);
    });
            detailsDiv.appendChild(platformList); // Add the <ul> to the details div
        } else {
            // Handle case where there are no platforms
            const noPlatforms = document.createElement('span');
            noPlatforms.textContent = ' N/A';
            platformsElement.appendChild(noPlatforms);
        }
        // --- End of Platform List Creation ---

        // Assemble the final display
        gameInfoDiv.appendChild(imgElement);    // Add thumbnail
        gameInfoDiv.appendChild(detailsDiv);   // Add text details
        resultsDiv.appendChild(gameInfoDiv); // Add the combined info to the main results area

    } // End displayGameDetails

    // --- Initial Application Setup ---
    loadSettings(); // Load saved theme and font preferences on page load

}); // End DOMContentLoaded wrapper

    