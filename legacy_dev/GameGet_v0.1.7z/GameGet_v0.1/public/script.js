const gameInput = document.getElementById('gameInput');
const searchButton = document.getElementById('searchButton');
const resultsDiv = document.getElementById('results');

// Define the base URL for the backend API
const API_BASE_URL = 'http://localhost:3000';

searchButton.addEventListener('click', searchGamesList);
gameInput.addEventListener('keypress', (event) => {
    if (event.key === 'Enter') {
        searchGamesList();
    }
});

// --- Step 1: Search for a list of games ---
async function searchGamesList() {
    const gameName = gameInput.value.trim();
    if (!gameName) {
        resultsDiv.innerHTML = '<p class="error-message">Please enter a game name.</p>';
        return;
    }

    resultsDiv.innerHTML = '<p class="info-message loading">Searching IGDB...</p>';
    searchButton.disabled = true;

    try {
        // Call the backend '/search' endpoint (which now returns a list)
        const response = await fetch(`${API_BASE_URL}/search?gameName=${encodeURIComponent(gameName)}`);

        if (!response.ok) {
            // Try to parse error json, provide fallback message
            const errorData = await response.json().catch(() => ({ error: 'Unknown server error or non-JSON response' }));
            throw new Error(`Server error: ${response.status} - ${errorData.error || response.statusText}`);
        }

        const searchResults = await response.json(); // Expecting an array: [{id, name}, ...]

        if (searchResults && searchResults.length > 0) {
            displaySearchResultsList(searchResults);
        } else {
             // Handle case where API call succeeded but returned empty list (should be caught by 404 now, but good practice)
             resultsDiv.innerHTML = `<p class="info-message">No games found matching "${gameName}".</p>`;
        }

    } catch (error) {
        console.error('Search List Fetch Error:', error);
        resultsDiv.innerHTML = `<p class="error-message">Error: ${error.message}. Could not fetch game list.</p>`;
    } finally {
         searchButton.disabled = false; // Re-enable button
    }
}

// --- Step 2: Display the list of clickable search results ---
function displaySearchResultsList(results) { // results is now an array of {id, name, year}
    resultsDiv.innerHTML = ''; // Clear previous results/loading message

    const instruction = document.createElement('p');
    instruction.classList.add('info-message');
    instruction.textContent = 'Select a game to view details:';
    resultsDiv.appendChild(instruction);

    const list = document.createElement('ul');
    list.classList.add('search-results-list');

    results.forEach(game => {
        const item = document.createElement('li');
        item.classList.add('search-result-item');
        item.dataset.gameId = game.id; // Store the game ID

        // Create span for the game name
        const nameSpan = document.createElement('span');
        nameSpan.textContent = game.name;
        nameSpan.classList.add('game-title'); // Optional class for specific styling

        // Create span for the release year
        const dateSpan = document.createElement('span');
        dateSpan.textContent = `(${game.year || 'N/A'})`; // Display year or N/A
        dateSpan.classList.add('game-shortdate'); // Add the specified class

        // Append spans to the list item
        item.appendChild(nameSpan);
        item.appendChild(dateSpan); // Add the date span next to the name

        // Add click listener
        item.addEventListener('click', () => {
            fetchGameDetails(game.id);
        });

        list.appendChild(item);
    });

    resultsDiv.appendChild(list);
}

// --- Step 3: Fetch full details for a selected game ID ---
async function fetchGameDetails(gameId) {
    resultsDiv.innerHTML = '<p class="info-message loading">Loading details...</p>'; // Show loading in the same div
    searchButton.disabled = true; // Optionally disable search while loading details

    try {
        const response = await fetch(`${API_BASE_URL}/details/${gameId}`);

        if (!response.ok) {
             const errorData = await response.json().catch(() => ({ error: 'Unknown server error or non-JSON response' }));
             throw new Error(`Server error: ${response.status} - ${errorData.error || response.statusText}`);
        }

        const gameDetails = await response.json(); // Expecting the full game data object
        displayGameDetails(gameDetails); // Display the fetched details

    } catch (error) {
        console.error('Fetch Details Error:', error);
        // Show error in the results area, allowing user to maybe search again
        resultsDiv.innerHTML = `<p class="error-message">Error loading details: ${error.message}.</p>`;
        // Consider adding a 'back to search' or clearing the input? For now, just show error.
    } finally {
        searchButton.disabled = false; // Re-enable search button
    }
}


// --- Step 4: Display the full game details (Original display logic) ---
function displayGameDetails(data) {
    // This function is mostly the same as the original displayResults
    if (!data || !data.name) {
         // This case might happen if the /details/:id somehow returns bad data
         resultsDiv.innerHTML = '<p class="info-message">Could not extract valid game details.</p>';
         return;
    }

    // Clear previous results (list or loading message)
    resultsDiv.innerHTML = '';

    const gameInfoDiv = document.createElement('div');
    gameInfoDiv.classList.add('game-info'); // Use existing class for styling

    // Thumbnail
    const imgElement = document.createElement('img');
    // Use a default placeholder if thumbnailUrl is null or empty
    imgElement.src = data.thumbnailUrl || 'https://via.placeholder.com/100x133?text=No+Art'; // Adjusted placeholder size maybe
    imgElement.alt = `${data.name} Box Art`;
    imgElement.onerror = () => { // Handle broken image links
        imgElement.src = 'https://via.placeholder.com/100x133?text=Art+Error';
        imgElement.alt = 'Image failed to load';
    };


    // Details container
    const detailsDiv = document.createElement('div');
    detailsDiv.classList.add('game-details');

    // Name
    const nameElement = document.createElement('h2');
    nameElement.textContent = data.name;
    detailsDiv.appendChild(nameElement);

    // Release Date
    const releaseElement = document.createElement('p');
    releaseElement.innerHTML = `<strong>Release Date:</strong> ${data.releaseDate || 'N/A'}`;
    detailsDiv.appendChild(releaseElement);

    // Platforms
    const platformsElement = document.createElement('p');
    platformsElement.innerHTML = '<strong>Platforms:</strong>';
    detailsDiv.appendChild(platformsElement);

    if (data.platforms && data.platforms.length > 0) {
        const platformList = document.createElement('ul');
        data.platforms.forEach(platform => {
            const li = document.createElement('li');
            li.textContent = platform;
            platformList.appendChild(li);
        });
        detailsDiv.appendChild(platformList);
    } else {
        const noPlatforms = document.createElement('span');
        noPlatforms.textContent = ' N/A'; // Add space for better formatting
        platformsElement.appendChild(noPlatforms);
    }

    // Assemble the game info display
    gameInfoDiv.appendChild(imgElement);
    gameInfoDiv.appendChild(detailsDiv);

    resultsDiv.appendChild(gameInfoDiv); // Add the combined info to the main results area
}